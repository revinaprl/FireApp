package id.revina.belajarchart;

public class Konfigurasi {

    //Dibawah ini merupakan Pengalamatan dimana Lokasi Skrip CRUD PHP disimpan
    //Pada tutorial Kali ini, karena kita membuat localhost maka alamatnya tertuju ke IP komputer
    //dimana File PHP tersebut berada
    //PENTING! JANGAN LUPA GANTI IP SESUAI DENGAN IP KOMPUTER DIMANA DATA PHP BERADA
    private static final String IP = "10.0.2.2";

    // URL (endpoint)
    public static final String URL_GET_ARAH = "http://" + IP + "/iot_restapi/arah.php";
    public static final String URL_GET_KECEPATAN = "http://" + IP + "/iot_restapi/kecepatan.php";
    public static final String URL_GET_KENAIKAN = "http://" + IP + "/iot_restapi/kenaikan.php";
    public static final String URL_GET_SENSOR = "http://" + IP + "/iot_restapi/sensor.php";
}
