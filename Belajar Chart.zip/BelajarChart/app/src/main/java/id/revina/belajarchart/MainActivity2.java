package id.revina.belajarchart;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.interfaces.datasets.ILineDataSet;
import com.github.mikephil.charting.utils.EntryXComparator;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.security.SecureRandom;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

public class MainActivity2 extends AppCompatActivity {

    LineChart lineChartKecepatan, lineChartKenaikan, lineChartArah;
    EditText etStatusApi, etWaktuSensor;
    Button btnCall, btnMessage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        lineChartKecepatan = findViewById(R.id.lineChartKecepatan);
        lineChartKenaikan = findViewById(R.id.lineChartKenaikan);
        lineChartArah = findViewById(R.id.lineChartArah);
        etStatusApi = findViewById(R.id.etStatusApi);
        etWaktuSensor = findViewById(R.id.etWaktuSensor);
        btnCall = findViewById(R.id.btnCall);
        btnMessage = findViewById(R.id.btnMessage);

        // Enables https connections
        handleSSLHandshake();


        // ========== STATUS & WAKTU ==========

        // Menampilkan data sensor
        tampilSensor();


        // ========== GRAFIK ==========

        // Garis Data Kecepatan
        LineDataSet lineDataSetKecepatan = new LineDataSet(dataValuesKecepatan(), "Kecepatan");
        lineDataSetKecepatan.setColor(Color.RED);

        // Garis Data Kenaikan
        LineDataSet lineDataSetKenaikan = new LineDataSet(dataValuesKenaikan(), "Kenaikan");
        lineDataSetKenaikan.setColor(Color.BLUE);

        // Garis Data Arah
        LineDataSet lineDataSetArah = new LineDataSet(dataValuesArah(), "Arah");
        lineDataSetArah.setColor(Color.GREEN);

        ArrayList<ILineDataSet> dataSetsKecepatan = new ArrayList<>();
        dataSetsKecepatan.add(lineDataSetKecepatan);

        ArrayList<ILineDataSet> dataSetsKenaikan = new ArrayList<>();
        dataSetsKenaikan.add(lineDataSetKenaikan);

        ArrayList<ILineDataSet> dataSetsArah = new ArrayList<>();
        dataSetsArah.add(lineDataSetArah);

        LineData lineDataKecepatan = new LineData(dataSetsKecepatan);
        lineChartKecepatan.setData(lineDataKecepatan);

        LineData lineDataKenaikan = new LineData(dataSetsKenaikan);
        lineChartKenaikan.setData(lineDataKenaikan);

        LineData lineDataArah = new LineData(dataSetsArah);
        lineChartArah.setData(lineDataArah);

        /*
        // Deskripsi
        Description description = new Description();
        description.setText("x");
        description.setTextSize(25);
        lineChartKecepatan.setDescription(description);

        // Warna background
        lineChartKecepatan.setBackgroundColor(Color.WHITE);

        // Border
        lineChartKecepatan.setDrawBorders(true);

        // Pesan yang ditampilkan jika data kosong
        lineChartKecepatan.setNoDataText("Tidak ada data!");
        lineChartKecepatan.setNoDataTextColor(Color.BLACK);

        // Animasi
        lineChartKecepatan.animateY(3000, Easing.EaseOutBounce);
*/

        // Load / Refresh chart
        lineChartKecepatan.invalidate();
        lineChartKenaikan.invalidate();
        lineChartArah.invalidate();


        // ========== TOMBOL-TOMBOL ==========

        // OnClickListener untuk panggilan
        btnCall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + "113"));
                startActivity(intent);
            }
        });

        // OnClickListener untuk SMS
        btnMessage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Uri uri = Uri.parse("smsto:113");
                Intent intent = new Intent(Intent.ACTION_SENDTO, uri);
                intent.putExtra("sms_body", "Ini isi SMS-nya 😉");
                startActivity(intent);
            }
        });
    }

    // Isi Data 1
    private List<Entry> dataValuesKecepatan() {
        // Ambil data dari API
        // return getData(Konfigurasi.URL_GET_KECEPATAN);

        // Buat data sendiri (manual)
        List<Entry> dataVals = new ArrayList<Entry>(); // Untuk menampung data yang akan ditampilkan di grafik

        Double[][] dataset = {
                // Rendah
                {23.0, 29.4},
                {34.0, 30.2},
                {39.0, 31.5},
                {44.0, 32.5},
                {57.0, 33.8},
                {63.0, 34.1},
                {72.0, 35.5},
                {79.0, 36.3},
                {83.0, 37.4},
                {91.0, 38.3},

                // Nominal
                {112.0, 39.4},
                {124.0, 40.2},
                {137.0, 41.4},
                {142.0, 42.6},
                {149.0, 43.1},
                {154.0, 44.5},
                {161.0, 45.3},
                {166.0, 46.1},
                {179.0, 47.5},
                {184.0, 48.3},

                // Tinggi
                {189.0, 49.2},
                {196.0, 50.8},
                {202.0, 51.5},
                {210.0, 52.4},
                {219.0, 53.7},
                {225.0, 54.5},
                {232.0, 55.8},
                {239.0, 56.3},
                {248.0, 57.4},
                {251.0, 58.6}
        };

        for (int i=0; i<dataset.length; i++) {
            if (dataset[i][1] >= 49.2) {
                dataVals.add(new Entry(dataset[i][0].floatValue(), dataset[i][1].floatValue()));
            }
        }

        // Tambah ke grafik
        Collections.sort(dataVals, new EntryXComparator());
        System.out.println("========================================================== kecepatan\n" + dataVals);

        return dataVals;
    }

    // Isi Data 2
    private List<Entry> dataValuesKenaikan() {
        // Ambil data dari API
        // return getData(Konfigurasi.URL_GET_KENAIKAN);

        // Buat data sendiri (manual)
        List<Entry> dataVals = new ArrayList<Entry>(); // Untuk menampung data yang akan ditampilkan di grafik

        // Tambah ke grafik
        dataVals.add(new Entry(Float.parseFloat("31.5"), Float.parseFloat("17.31")));
        dataVals.add(new Entry(Float.parseFloat("29.4"), Float.parseFloat("17.01")));
        dataVals.add(new Entry(Float.parseFloat("30.2"), Float.parseFloat("17.02")));
        Collections.sort(dataVals, new EntryXComparator());
        System.out.println("========================================================== kenaikan\n" + dataVals);

        return dataVals;
    }

    // Isi Data 3
    private List<Entry> dataValuesArah() {
        // Ambil data dari API
        // return getData(Konfigurasi.URL_GET_ARAH);

        // Buat data sendiri (manual)
        List<Entry> dataVals = new ArrayList<Entry>(); // Untuk menampung data yang akan ditampilkan di grafik

        // Tambah ke grafik
        dataVals.add(new Entry(Float.parseFloat("31.5"), 1));
        dataVals.add(new Entry(Float.parseFloat("29.4"), 1));
        dataVals.add(new Entry(Float.parseFloat("30.2"), 1));
        Collections.sort(dataVals, new EntryXComparator());
        System.out.println("========================================================== arah\n" + dataVals);

        return dataVals;
    }

    // Ambil data dati API
    private List<Entry> getData(String url) {
        // Instantiate the RequestQueue.
        RequestQueue queue = Volley.newRequestQueue(this);

        // Tempat untuk menampung data yang akan ditampilkan di grafik
        List<Entry> dataVals = new ArrayList<Entry>();

        // Request a string response from the provided URL.
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
            new Response.Listener<String>() {
                JSONObject jsonObject = null;

                @Override
                public void onResponse(String response) {
                    try {
                        jsonObject = new JSONObject(response);
                        JSONArray result = jsonObject.getJSONArray("result");

                        switch (url) {
                            case Konfigurasi.URL_GET_KECEPATAN:
                                for(int i = 0; i<result.length(); i++){
                                    JSONObject jo = result.getJSONObject(i); // Ambil data pada baris i, dimulai dari 0

                                    String waktu_kec = jo.getString("waktu_kec");

                                    String suhu = jo.getString("suhu");
                                    suhu = suhu.split(",")[0] + "." + suhu.split(",")[1]; // Mengubah "1,5" menjadi "1.5"

                                    // Tambah ke grafik
                                    dataVals.add(new Entry(Float.parseFloat(waktu_kec), Float.parseFloat(suhu)));
                                }
                                System.out.println("========================================================== kecepatan\n" + dataVals);
                                break;
                            case Konfigurasi.URL_GET_KENAIKAN:
                                for(int i = 0; i<result.length(); i++){
                                    JSONObject jo = result.getJSONObject(i); // Ambil data pada baris i, dimulai dari 0

                                    String waktu_ken = jo.getString("waktu_ken");
                                    String[] waktu_ken_split = waktu_ken.split(":");
                                    waktu_ken = waktu_ken_split[1] + "." + waktu_ken_split[2]; // Contoh hasil "10.59"

                                    String suhu = jo.getString("suhu");
                                    suhu = suhu.split(",")[0] + "." + suhu.split(",")[1]; // Mengubah "1,5" menjadi "1.5"

                                    // Tambah ke grafik
                                    dataVals.add(new Entry(Float.parseFloat(waktu_ken), Float.parseFloat(suhu)));
                                }
                                System.out.println("========================================================== kenaikan\n" + dataVals);
                                break;
                            case Konfigurasi.URL_GET_ARAH:
                                for(int i = 0; i<result.length(); i++){
                                    JSONObject jo = result.getJSONObject(i); // Ambil data pada baris i, dimulai dari 0

                                    String titik = jo.getString("titik");
                                    String suhu = jo.getString("suhu");
                                    suhu = suhu.split(",")[0] + "." + suhu.split(",")[1]; // Mengubah "1,5" menjadi "1.5"

                                    // Tambah ke grafik
                                    dataVals.add(new Entry(Float.parseFloat(titik), Float.parseFloat((suhu))));
                                }
                                System.out.println("========================================================== arah\n" + dataVals);
                                break;
                            default:
                                Log.e("Error", "Endpoint tidak tersedia");
                        }

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            },

            new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    // If there a HTTP error then add a note to our repo list.
                    Log.e("Volley", error.toString());
                }
            }
        );

        // Add the request to the RequestQueue.
        queue.add(stringRequest);

        // Urutkan entry ascending berdasarkan x
        Collections.sort(dataVals, new EntryXComparator());

        return dataVals;
    }

    // Tampil Data Sensor
    private void tampilSensor() {
        // Instantiate the RequestQueue.
        RequestQueue queue = Volley.newRequestQueue(this);

        // Request a string response from the provided URL.
        StringRequest stringRequest = new StringRequest(Request.Method.GET, Konfigurasi.URL_GET_SENSOR,
                new Response.Listener<String>() {
                    JSONObject jsonObject = null;

                    @Override
                    public void onResponse(String response) {
                        try {
                            jsonObject = new JSONObject(response);
                            JSONArray result = jsonObject.getJSONArray("result");

                            for(int i = 0; i<result.length(); i++){
                                JSONObject jo = result.getJSONObject(i); // Ambil data pada baris i, dimulai dari 0

                                String api = jo.getString("api");
                                String waktu_api = jo.getString("waktu_api");

                                etStatusApi.setText(api);
                                etWaktuSensor.setText(waktu_api);
                            }

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },

                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        // If there a HTTP error then add a note to our repo list.
                        Log.e("Volley", error.toString());
                    }
                }
        );

        // Add the request to the RequestQueue.
        queue.add(stringRequest);
    }

    /**
     * Enables https connections
     */
    @SuppressLint("TrulyRandom")
    public static void handleSSLHandshake() {
        try {
            TrustManager[] trustAllCerts = new TrustManager[]{new X509TrustManager() {
                public X509Certificate[] getAcceptedIssuers() {
                    return new X509Certificate[0];
                }

                @Override
                public void checkClientTrusted(X509Certificate[] certs, String authType) {
                }

                @Override
                public void checkServerTrusted(X509Certificate[] certs, String authType) {
                }
            }};

            SSLContext sc = SSLContext.getInstance("SSL");
            sc.init(null, trustAllCerts, new SecureRandom());
            HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
            HttpsURLConnection.setDefaultHostnameVerifier(new HostnameVerifier() {
                @Override
                public boolean verify(String arg0, SSLSession arg1) {
                    return true;
                }
            });
        } catch (Exception ignored) {
        }
    }
}